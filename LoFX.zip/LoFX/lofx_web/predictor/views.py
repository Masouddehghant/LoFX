import os
import uuid
from datetime import datetime

import joblib
import pandas as pd
from django.conf import settings
from django.http import HttpResponse, FileResponse, Http404
from django.shortcuts import render
from .forms import UploadFileForm

# =========================
# Load model resources once
# =========================
MODEL_PATH = os.path.join(settings.BASE_DIR, "trained_model", "lofx_model.pkl")
FEATURES_PATH = os.path.join(settings.BASE_DIR, "trained_model", "lofx_features.pkl")
CONSTRAINT_PATH = os.path.join(settings.BASE_DIR, "trained_model", "gnomad_constraint.tsv")
OUTPUT_DIR = os.path.join(settings.BASE_DIR, "outputs")

os.makedirs(OUTPUT_DIR, exist_ok=True)

model = joblib.load(MODEL_PATH)
scoring_cols = joblib.load(FEATURES_PATH)
constraint = pd.read_csv(CONSTRAINT_PATH, sep="\t")

LOF_TYPES = {"stopgain", "stoploss", "startloss"}


def read_uploaded_file(uploaded_file):
    name = uploaded_file.name.lower()
    if name.endswith(".tsv") or name.endswith(".txt"):
        return pd.read_csv(uploaded_file, sep="\t")
    elif name.endswith(".csv"):
        return pd.read_csv(uploaded_file)
    else:
        raise ValueError("Only TSV, TXT, or CSV files are supported.")


def harmonise_columns(df, expected_cols):
    """Match column names regardless of upper/lower case
    (e.g. ANNOVAR writes 1000g2015aug_all, the model uses 1000g2015aug_ALL)."""
    lower_map = {c.lower(): c for c in expected_cols}
    rename = {c: lower_map[c.lower()] for c in df.columns
              if c.lower() in lower_map and c != lower_map[c.lower()]}
    return df.rename(columns=rename)


def preprocess_input(df, constraint_df, scoring_cols):
    df = harmonise_columns(df, list(scoring_cols) + ["Gene.refGene", "ExonicFunc.refGene"])
    required_cols = ["Gene.refGene", "ExonicFunc.refGene"]
    for col in required_cols:
        if col not in df.columns:
            raise ValueError(f"Missing required column: {col}")

    df = df.merge(
        constraint_df,
        on="Gene.refGene",
        how="left",
        validate="many_to_one"
    )

    for col in scoring_cols:
        if col not in df.columns:
            df[col] = pd.NA

    for col in scoring_cols:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    return df


def run_lofx_prediction(df):
    df = df.copy()
    df["ExonicFunc.refGene"] = df["ExonicFunc.refGene"].astype(str).str.strip().str.lower()

    n_features = len(scoring_cols)
    df["available_feature_count"] = df[scoring_cols].notna().sum(axis=1)
    df["Available_features"] = (
        df["available_feature_count"].astype(int).astype(str) + "/" + str(n_features)
    )

    df["LoFX_score"] = pd.NA
    df["LoFX_label"] = pd.NA
    df["LoFX_status"] = pd.NA

    is_lof = df["ExonicFunc.refGene"].isin(LOF_TYPES)

    df.loc[~is_lof, "LoFX_status"] = "not lof"
    df.loc[~is_lof, "LoFX_label"] = "not lof"

    # A prediction is made whenever at least one model feature is available,
    # as in the analyses reported in the manuscript. XGBoost handles missing
    # values without imputation.
    no_features = is_lof & (df["available_feature_count"] == 0)
    df.loc[no_features, "LoFX_status"] = "no model features available"
    df.loc[no_features, "LoFX_label"] = "not predicted"

    valid = is_lof & (df["available_feature_count"] >= 1)

    if valid.any():
        X_valid = df.loc[valid, scoring_cols]
        probs = model.predict_proba(X_valid)[:, 1]

        df.loc[valid, "LoFX_score"] = probs
        df.loc[valid, "LoFX_label"] = [
            "Pathogenic" if p >= 0.5 else "Benign" for p in probs
        ]
        df.loc[valid, "LoFX_status"] = "predicted"

    return df


def upload_and_predict(request):
    form = UploadFileForm()

    result_table = None
    download_url = None
    error = None
    uploaded_filename = None
    upload_date = None
    upload_time = None
    job_status = None
    progress = 0

    if request.method == "POST":
        action = request.POST.get("action")

        try:
            if action == "sample":
                sample_path = os.path.join(settings.BASE_DIR, "sample_data", "sample_input.tsv")
                if not os.path.exists(sample_path):
                    raise FileNotFoundError("Sample input file not found.")

                df = pd.read_csv(sample_path, sep="\t")
                uploaded_filename = "sample_input.tsv"

            elif action == "upload":
                form = UploadFileForm(request.POST, request.FILES)

                if not form.is_valid():
                    raise ValueError("Please upload a valid input file.")

                uploaded_file = request.FILES["file"]
                df = read_uploaded_file(uploaded_file)
                uploaded_filename = uploaded_file.name

            else:
                raise ValueError("Invalid action.")

            df = preprocess_input(df, constraint, scoring_cols)
            result_df = run_lofx_prediction(df)

            preview_cols = [
                "Chr", "Start", "End", "Ref", "Alt",
                "Gene.refGene", "ExonicFunc.refGene",
                "Available_features",
                "LoFX_score", "LoFX_label", "LoFX_status"
            ]
            existing_cols = [c for c in preview_cols if c in result_df.columns]
            result_df = result_df[existing_cols]

            out_name = f"lofx_result_{uuid.uuid4().hex[:8]}.csv"
            out_path = os.path.join(OUTPUT_DIR, out_name)
            result_df.to_csv(out_path, index=False)

            result_table = result_df.head(20).to_html(index=False, classes="result-table")
            download_url = f"/download/{out_name}/"

            now = datetime.now()
            upload_date = now.strftime("%Y-%m-%d")
            upload_time = now.strftime("%H:%M:%S")
            job_status = "Finished job"
            progress = 100

        except Exception as e:
            error = str(e)
            job_status = "Failed"
            progress = 100

    return render(request, "predictor/upload.html", {
        "form": form,
        "result_table": result_table,
        "download_url": download_url,
        "error": error,
        "uploaded_filename": uploaded_filename,
        "upload_date": upload_date,
        "upload_time": upload_time,
        "job_status": job_status,
        "progress": progress,
    })


def download_result(request, filename):
    file_path = os.path.join(OUTPUT_DIR, filename)

    if not os.path.exists(file_path):
        return HttpResponse("File not found.", status=404)

    with open(file_path, "rb") as f:
        response = HttpResponse(f.read(), content_type="text/csv")
        response["Content-Disposition"] = f'attachment; filename="{filename}"'
        return response


def download_sample(request):
    sample_path = os.path.join(settings.BASE_DIR, "sample_data", "sample_input.tsv")

    if not os.path.exists(sample_path):
        raise Http404("Sample file not found.")

    return FileResponse(
        open(sample_path, "rb"),
        as_attachment=True,
        filename="sample_input.tsv"
    )
