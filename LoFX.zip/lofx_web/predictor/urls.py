from django.urls import path
from . import views

urlpatterns = [
    path("", views.upload_and_predict, name="upload_and_predict"),
    path("download/<str:filename>/", views.download_result, name="download_result"),
    path("download-sample/", views.download_sample, name="download_sample"),
]
